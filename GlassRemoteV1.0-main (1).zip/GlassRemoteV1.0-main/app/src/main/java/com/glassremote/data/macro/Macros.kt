package com.glassremote.data.macro

import com.glassremote.data.adb.Adb
import kotlinx.coroutines.delay

object Macros {
    suspend fun runWatchStremioMacro(onProgress: (String) -> Unit): Result<Boolean> {
        return try {
            onProgress("Waking up TV...")
            Adb.executeShell("input keyevent 26")
            delay(1000L)

            onProgress("Launching Stremio Activity...")
            Adb.executeShell("am start -n com.stremio.one/.MainActivity")
            delay(2000L)

            onProgress("Macro executed successfully")
            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
