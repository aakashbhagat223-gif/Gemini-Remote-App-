package com.glassremote.data.adb

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.Socket

object Adb {
    private const val HOST = "192.168.31.116"
    private const val PORT = 5555
    private const val TAG = "AdbEngine"

    suspend fun isConnected(): Boolean = withContext(Dispatchers.IO) {
        try {
            Socket(HOST, PORT).use { true }
        } catch (e: Exception) {
            Log.e(TAG, "Connection verification failed: ${e.message}")
            false
        }
    }

    suspend fun executeShell(command: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            Socket(HOST, PORT).use { socket ->
                val output = socket.getOutputStream()
                val input = BufferedReader(InputStreamReader(socket.getInputStream()))
                output.write("shell:$command\n".toByteArray(Charsets.UTF_8))
                output.flush()

                val response = StringBuilder()
                var line: String?
                while (input.readLine().also { line = it } != null) {
                    response.append(line).append("\n")
                }
                Result.success(response.toString().trim())
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to execute shell line: $command, Error: ${e.message}")
            Result.failure(e)
        }
    }
}
