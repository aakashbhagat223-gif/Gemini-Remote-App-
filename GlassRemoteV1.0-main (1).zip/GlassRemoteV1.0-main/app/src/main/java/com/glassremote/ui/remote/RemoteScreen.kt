package com.glassremote.ui.remote

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun RemoteScreen(viewModel: RemoteViewModel) {
    val tvConnected by viewModel.tvConnected.collectAsState()
    val macroProgress by viewModel.macroProgress.collectAsState()

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Row(
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Xiaomi TV Host", style = MaterialTheme.typography.titleMedium)
                Text(
                    text = if (tvConnected) "ADB Connected" else "Searching Network...",
                    color = if (tvConnected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
            }
        }

        if (macroProgress.isNotEmpty()) {
            Text(text = macroProgress, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(8.dp))
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Button(onClick = { viewModel.sendTvKey(19) }) { Text("▲") }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Button(onClick = { viewModel.sendTvKey(21) }) { Text("◀") }
            Button(onClick = { viewModel.sendTvKey(23) }) { Text("OK") }
            Button(onClick = { viewModel.sendTvKey(22) }) { Text("▶") }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Button(onClick = { viewModel.sendTvKey(20) }) { Text("▼") }
        }
        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = { viewModel.executeStremioAutomation() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Watch Stremio (Automated Macro)")
        }
    }
}
