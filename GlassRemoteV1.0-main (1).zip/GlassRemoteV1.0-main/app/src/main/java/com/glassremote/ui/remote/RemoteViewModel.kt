package com.glassremote.ui.remote

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.glassremote.data.adb.Adb
import com.glassremote.data.macro.Macros
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class RemoteViewModel : ViewModel() {
    private val _tvConnected = MutableStateFlow(false)
    val tvConnected: StateFlow<Boolean> = _tvConnected.asStateFlow()

    private val _macroProgress = MutableStateFlow("")
    val macroProgress: StateFlow<String> = _macroProgress.asStateFlow()

    private val _nowPlayingTitle = MutableStateFlow("Nothing Playing")
    val nowPlayingTitle: StateFlow<String> = _nowPlayingTitle.asStateFlow()

    init {
        pollTvConnection()
    }

    fun pollTvConnection() {
        viewModelScope.launch {
            _tvConnected.value = Adb.isConnected()
        }
    }

    fun sendTvKey(keyCode: Int) {
        viewModelScope.launch {
            Adb.executeShell("input keyevent $keyCode")
        }
    }

    fun executeStremioAutomation() {
        viewModelScope.launch {
            Macros.runWatchStremioMacro { status ->
                _macroProgress.value = status
            }
        }
    }
}
