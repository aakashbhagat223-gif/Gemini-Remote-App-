package com.glassremote.ui.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun DashboardScreen() {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("System Diagnostics Dashboard", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        Card(modifier = Modifier.fillMaxWidth().height(120.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Target Device: Xiaomi Living Room TV", style = MaterialTheme.typography.titleMedium)
                Text("Resolved Address: 192.168.31.116")
                Text("Active Session Layer: Pure Shell Injections Active")
            }
        }
    }
}
