package com.glassremote

import android.os.Bundle
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.glassremote.ui.remote.RemoteScreen
import com.glassremote.ui.remote.RemoteViewModel
import com.glassremote.ui.theme.GlassRemoteTheme

class MainActivity : ComponentActivity() {

    private lateinit var mediaSession: MediaSessionCompat
    private val viewModel: RemoteViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mediaSession = MediaSessionCompat(this, "GlassRemoteMediaEngine").apply {
            isActive = true
            setPlaybackState(
                PlaybackStateCompat.Builder()
                    .setState(PlaybackStateCompat.STATE_PLAYING, PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN, 1.0f)
                    .setActions(PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE)
                    .build()
            )
        }

        setContent {
            GlassRemoteTheme {
                RemoteScreen(viewModel = viewModel)
            }
        }

        synchronizeLockScreenCard("Two and a Half Men", "Streaming on Xiaomi TV")
    }

    private fun synchronizeLockScreenCard(title: String, subtitle: String) {
        val metadata = MediaMetadataCompat.Builder()
            .putString(MediaMetadataCompat.METADATA_KEY_TITLE, title)
            .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, subtitle)
            .build()
        mediaSession.setMetadata(metadata)
    }

    override fun onDestroy() {
        mediaSession.release()
        super.onDestroy()
    }
}
